# from app.routes.badges.routes import badge_bp

# app.register_blueprint(badge_bp)
